<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
        <p class="p_create">Create Account</p>
        <form id="form_input" method="post" action="create_account_validation.php">
        <input type="fullname" name="fullname" id="fullname" placeholder="Full name" class="form-control" required >
        <input type="text" name="email" id="email" placeholder="Email" class="form-control" required >
        <input type="password" name="password" id="password" placeholder="Password" class="form-control" required>        
        <input type="submit" id="btn_submit" class="btn btn-lg btn-success form-control" value="Sign Up">
        </form>
</body>
</html>