CREATE TABLE `data_member` (
  `id_member` int(12) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(360) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  PRIMARY KEY (`id_member`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
